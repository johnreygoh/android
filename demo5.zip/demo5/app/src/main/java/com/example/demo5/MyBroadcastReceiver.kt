package com.example.demo5

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class MyBroadcastReceiver : BroadcastReceiver() {

    //ctrl + i to implement methods
    //this function will run when the user changes to airplane mode
    override fun onReceive(context: Context?, intent: Intent?) {

        // if getbooleanextra contains null, it will directly
        // return back
        val isAirplaneModeEnabled = intent?.getBooleanExtra("state",false)?:return

        // check if airplane mode is enabled
        if(isAirplaneModeEnabled){
            Toast.makeText(context, "Airplane Mode Enabled", Toast.LENGTH_LONG).show()
        }else{
            Toast.makeText(context, "Airplane Mode Disabled", Toast.LENGTH_LONG).show()
        }



    }
}