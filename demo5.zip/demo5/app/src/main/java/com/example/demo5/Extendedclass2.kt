package com.example.demo5

import android.util.Log

class Extendedclass2(officeaddress:String,val telno:String): InheritanceDemo3(officeaddress) {

    fun displayOfficeContact(){
        Log.d("constructordemo","$officeaddress:$telno")
    }


}