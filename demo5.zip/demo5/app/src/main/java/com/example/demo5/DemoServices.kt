package com.example.demo5

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_demo_services.btnStartService
import kotlinx.android.synthetic.main.activity_demo_services.btnStopService

class DemoServices : AppCompatActivity(),View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_demo_services)

        // button definitions
        btnStartService.setOnClickListener(this)
        btnStopService.setOnClickListener(this)
    }

    override fun onClick(view:View){
        if(view === btnStartService){
            startService(Intent(this,SampleService1::class.java))
        }

        if(view === btnStopService){
            stopService(Intent(this,SampleService1::class.java))
        }

    }



}