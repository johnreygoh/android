package com.example.demo5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DemoContentProvider : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_demo_content_provider)
    }
}