package com.example.demo5

import android.util.Log

class Contractualstaff(name:String,email:String,val department:String,val workmonths: Int)
    : Employee(name,email) {

    fun displayContractualStaff(){
        Log.d("constructordemo","$name:$email:$department:$workmonths")
    }



}