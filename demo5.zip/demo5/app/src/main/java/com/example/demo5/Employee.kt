package com.example.demo5

import android.util.Log

open class Employee(val name:String,val email:String = "anonymous@abc.com") {

    fun displayEmployeeInfo(){
        Log.d("constructordemo","$name:$email")
    }

}