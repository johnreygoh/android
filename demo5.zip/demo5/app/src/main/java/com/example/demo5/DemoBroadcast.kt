package com.example.demo5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.PersistableBundle
import android.widget.Toast

class DemoBroadcast : AppCompatActivity() {

    lateinit var receiver:MyBroadcastReceiver

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_demo_broadcast)

        receiver = MyBroadcastReceiver()

        // listen to broadcast
        IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            .also{
                registerReceiver(receiver,it)
            }
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(receiver)
    }



}