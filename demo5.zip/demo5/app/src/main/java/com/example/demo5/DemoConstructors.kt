package com.example.demo5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class DemoConstructors : AppCompatActivity() {

    val rstaff = Regularstaff("harry","harry@abc.com","MIS")
    val cstaff = Contractualstaff("ron","ron@abc.com","HR",5)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_demo_constructors)

        rstaff.displayRegularStaff()
        cstaff.displayContractualStaff()


    }

}