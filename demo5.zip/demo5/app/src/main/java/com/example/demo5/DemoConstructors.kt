package com.example.demo5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DemoConstructors : AppCompatActivity() {

    lateinit var inheriteddemo:InheritanceDemo1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_demo_constructors)

        inheriteddemo = InheritanceDemo1()
        inheriteddemo.mystart()

    }


}