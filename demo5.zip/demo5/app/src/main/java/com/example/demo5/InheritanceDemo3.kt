package com.example.demo5

import android.util.Log

open class InheritanceDemo3(val officeaddress:String) {

    fun displayOfficeAddress(){
        Log.d("constructordemo","Your office is in $officeaddress")
    }


}