package com.example.demo5

import android.util.Log

class InheritanceDemo2 {

    val officeaddress2 = "Pasig"

    fun greetme2(){
        Log.d("constructordemo","This is from inheritance 2")
    }


}