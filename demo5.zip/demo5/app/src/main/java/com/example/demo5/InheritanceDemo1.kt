package com.example.demo5

import android.util.Log

open class InheritanceDemo1 {

    val mybaseclassname = "InheritanceDemo1"

    open fun mystart(){
        Log.d("demo5","this is from base class")
    }


}