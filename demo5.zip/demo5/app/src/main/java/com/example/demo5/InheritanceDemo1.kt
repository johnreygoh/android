package com.example.demo5

import android.util.Log

// base class
open class InheritanceDemo1 {

    val officeaddress = "Makati"

    fun greetme(){
        Log.d("constructordemo","This is from InheritanceDemo1")
    }


}