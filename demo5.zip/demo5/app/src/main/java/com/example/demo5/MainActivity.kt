package com.example.demo5

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.button1

import kotlinx.android.synthetic.main.activity_main.button3
import kotlinx.android.synthetic.main.activity_main.button4

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button1.setOnClickListener {
            var int1 = Intent(applicationContext,DemoBroadcast::class.java)
            startActivity(int1)
        }



        button3.setOnClickListener {
            var int3 = Intent(applicationContext,DemoServices::class.java)
            startActivity(int3)
        }

        button4.setOnClickListener {
            var int4 = Intent(applicationContext,DemoConstructors::class.java)
            startActivity(int4)
        }




    }
}