package com.example.demo5

class Class1:InheritanceDemo1() {

    var myclassname = mybaseclassname

    override fun mystart() {
        super.mystart()
    }


}