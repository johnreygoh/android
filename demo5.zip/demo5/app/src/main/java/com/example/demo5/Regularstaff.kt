package com.example.demo5

import android.util.Log

class Regularstaff(name:String,email:String,val department:String):
    Employee(name, email) {

        fun displayRegularStaff(){
            Log.d("constructordemo","$name:$email:$department")
        }


}