package com.example.demo5

class Extendedclass1:InheritanceDemo1() {

    val indemo2 = InheritanceDemo2()

    fun function1(){
        greetme()
        indemo2.greetme2()
    }

}