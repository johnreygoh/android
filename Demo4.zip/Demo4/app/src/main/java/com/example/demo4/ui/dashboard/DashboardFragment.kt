package com.example.demo4.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.demo4.databinding.FragmentDashboardBinding
import kotlinx.android.synthetic.main.fragment_dashboard.chkDatabaseAdmin
import kotlinx.android.synthetic.main.fragment_dashboard.chkMobileDev
import kotlinx.android.synthetic.main.fragment_dashboard.chkWebdev
import kotlinx.android.synthetic.main.fragment_dashboard.spiPrefSched
import kotlinx.android.synthetic.main.fragment_dashboard.swiFilipino
import kotlinx.android.synthetic.main.fragment_dashboard.swiMarried
import kotlinx.android.synthetic.main.fragment_dashboard.view.button1
import kotlinx.android.synthetic.main.fragment_dashboard.view.txtFirstname
import kotlinx.android.synthetic.main.fragment_dashboard.view.txtLastname

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val dashboardViewModel =
            ViewModelProvider(this).get(DashboardViewModel::class.java)

        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // access and manage views
        root.button1.setOnClickListener {

            var fn = root.txtFirstname.text.toString()
            var ln = root.txtLastname.text.toString()
            var s1 = ""
            if(chkWebdev.isChecked){ s1 = "Web Development"}

            var s2 = ""
            if(chkMobileDev.isChecked){ s2 = "Mobile Development"}

            var s3 = ""
            if(chkDatabaseAdmin.isChecked){ s3 = "Database Administration"}

            var cstatus = "single"
            if(swiMarried.isChecked){ cstatus = "married" }

            var citizenship = "not Filipino"
            if(swiFilipino.isChecked){ citizenship = "Filipino" }

            var sched = spiPrefSched.selectedItem.toString()

            var answer = "$fn $ln\n$s1\n$s2\n$s3\n$cstatus\n$citizenship\n$sched"
            Toast.makeText(activity,answer,Toast.LENGTH_LONG).show()

        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}