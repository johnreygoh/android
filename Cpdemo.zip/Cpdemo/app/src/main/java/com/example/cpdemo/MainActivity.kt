package com.example.cpdemo

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    // onTouchEvent
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        // input method manager
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(currentFocus!!.windowToken,0)
        return true
    }

    fun onClickAddData(view: View?){

        // add record, id + name
        val values = ContentValues()

        // fetch text from user
        var txtName = findViewById<View>(R.id.textName) as EditText
        values.put(MyContentProvider.name, txtName.text.toString())

        // insert into database through content provider->content resolver
        contentResolver.insert(MyContentProvider.CONTENT_URI,values)

        Toast.makeText(baseContext,"New Record added",Toast.LENGTH_LONG).show()

    }

    @SuppressLint("Range")
    fun onClickLoadData(view: View?){

        // inserting table details in the textview
        val resultView = findViewById<View>(R.id.res) as TextView

        // another way of specifying URI
        val cursor = contentResolver.query(
            Uri.parse("content://com.demo.user.provider/users"),
            null, null,null,null)

        // iteration to display to textview
        if(cursor!!.moveToFirst()){
            // use string builder
            val strbuild = StringBuilder()
            while(!cursor.isAfterLast){
                strbuild.append("""
                    
                    ${cursor.getString(cursor.getColumnIndex("id"))} - ${cursor.getString(cursor.getColumnIndex("name"))}
                """.trimIndent())
                cursor.moveToNext()
            }

            resultView.text = strbuild
        } else {
            resultView.text = "No Records Found"
        }



    }






}