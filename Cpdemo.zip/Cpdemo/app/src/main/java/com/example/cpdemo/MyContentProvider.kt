package com.example.cpdemo

import android.content.ContentProvider
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.UriMatcher
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteQueryBuilder
import android.net.Uri


class MyContentProvider : ContentProvider() {


    private var db: SQLiteDatabase? = null

    companion object{
        // define authority so that other apps can access it
        const val PROVIDER_NAME = "com.demo.user.provider"

        // define content URI
        const val Url = "content://$PROVIDER_NAME/users"

        // parse the content URL
        val CONTENT_URI = Uri.parse(Url)

        const val id = "id"
        const val name = "name"
        const val uriCode = 1
        var uriMatcher:UriMatcher? = null
        private val values: HashMap<String,String>? = null

        const val DATABASE_NAME = "UserDB"
        const val TABLE_NAME = "Users"
        const val DATABASE_VERSION = 1

        //sql query to create table
        const val CREATE_DB_TABLE =
            ("CREATE TABLE " + TABLE_NAME
                    + " (id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "  name TEXT NOT NULL);")

        // initializer block to utilize functions automatically
        init {
            // to match content URI
            // every time user access table under content provider
            uriMatcher = UriMatcher(UriMatcher.NO_MATCH)

            //access table IF uri found match
            uriMatcher!!.addURI(
                PROVIDER_NAME,
                "users",
                uriCode
            )

            //access row
            uriMatcher!!.addURI(
                PROVIDER_NAME,
                "users/*",
                uriCode
            )
        }
    }


    override fun getType(uri: Uri): String? {
        return when (uriMatcher!!.match(uri)){
            uriCode -> "vnd.android.cursor.dir/users"
            else -> throw IllegalArgumentException("Unsupported URI: $uri")
        }
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {

        val rowID = db!!.insert(TABLE_NAME,"",values)
        if(rowID > 0){
            val _uri = ContentUris.withAppendedId(CONTENT_URI,rowID)
            context!!.contentResolver.notifyChange(_uri,null)
            return _uri
        } else throw  SQLiteException("Failed to add a record into $uri")

    }

    // create database and table
    override fun onCreate(): Boolean {

        val context = context
        val dbHelper = DatabaseHelper(context)  // custom class
        db = dbHelper.writableDatabase
        return if(db != null){
            true
        } else false
    }

    override fun query(
        uri: Uri, projection: Array<String>?, selection: String?,
        selectionArgs: Array<String>?, sortOrder: String?
    ): Cursor? {

        var sortOrder = sortOrder
        var qb = SQLiteQueryBuilder()
        qb.tables = TABLE_NAME

        when (uriMatcher!!.match(uri)){
            uriCode -> qb.projectionMap= values
            else -> throw IllegalArgumentException("Unknown URI:$uri")
        }

        if(sortOrder != null || sortOrder===""){
            sortOrder = id
        }

        val mycursor = qb.query(
            db,
            projection,
            selection,
            selectionArgs,
            null,
            null,
            sortOrder)

        mycursor.setNotificationUri(context!!.contentResolver,uri)
        return mycursor

    }

    override fun update(
        uri: Uri, values: ContentValues?, selection: String?,
        selectionArgs: Array<String>?
    ): Int {

        // return Integer count number of affected update
        var count = 0
        count = when (uriMatcher!!.match(uri)){
            uriCode -> db!!.update(TABLE_NAME,values,selection,selectionArgs)
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
        context!!.contentResolver.notifyChange(uri,null)
        return count
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {

        var count = 0
        count = when (uriMatcher!!.match(uri)){
            uriCode -> db!!.delete(TABLE_NAME,selection,selectionArgs)
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
        context!!.contentResolver.notifyChange(uri,null)
        return count

    }


    // class inside a class, constructor internal
    private class DatabaseHelper internal constructor(context: Context?)
        :SQLiteOpenHelper(
            context,
            DATABASE_NAME,
            null,
            DATABASE_VERSION
    ){
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(CREATE_DB_TABLE)
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
            onCreate(db)
        }

    }


}