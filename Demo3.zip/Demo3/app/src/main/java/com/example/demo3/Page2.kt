package com.example.demo3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Page2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page2)
    }
}