package com.example.demo3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_page1process.btnBacktoform
import kotlinx.android.synthetic.main.activity_page1process.txtoutEmail
import kotlinx.android.synthetic.main.activity_page1process.txtoutName
import kotlinx.android.synthetic.main.activity_page1process.txtoutPhone

class Page1process : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page1process)


        var myname = intent.getStringExtra("myname").toString()
        var myemail = intent.getStringExtra("myemail").toString()
        var myphone = intent.getStringExtra("myphone").toString()

        txtoutName.text = myname
        txtoutEmail.text = myemail
        txtoutPhone.text = myphone

        btnBacktoform.setOnClickListener {
            var page1 = Intent(this, Page1::class.java)
            startActivity(page1)
        }


    }
}