package com.example.demo3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_page1.btnSubmit
import kotlinx.android.synthetic.main.activity_page1.txtEmail
import kotlinx.android.synthetic.main.activity_page1.txtName
import kotlinx.android.synthetic.main.activity_page1.txtPhone

class Page1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page1)

        btnSubmit.setOnClickListener {
            val toprocess = Intent(this,Page1process::class.java)

            toprocess.apply {
                putExtra("myname", txtName.text.toString())
                putExtra("myemail", txtEmail.text.toString())
                putExtra("myphone",txtPhone.text.toString())
            }

            startActivity(toprocess)
        }




    }
}