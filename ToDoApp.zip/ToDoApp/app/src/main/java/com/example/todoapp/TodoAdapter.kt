package com.example.todoapp

import android.graphics.Paint
import android.support.v4.os.IResultReceiver._Parcel
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.view.menu.MenuView.ItemView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_todo.view.chkDone
import kotlinx.android.synthetic.main.item_todo.view.txtItem

class TodoAdapter(private val todos:MutableList<Todo>)
    :RecyclerView.Adapter<TodoAdapter.TodoViewHolder>() {

    class TodoViewHolder(itemView:View):RecyclerView.ViewHolder(itemView)

    // ctrl + i to implement required methods
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TodoViewHolder {

        // layout xml utilize
        return TodoViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_todo,parent,false)
        )

    }

    override fun onBindViewHolder(holder: TodoViewHolder, position: Int) {

        // get current to-do item
        val currTodo = todos[position]
        holder.itemView.txtItem.text = currTodo.title
        holder.itemView.chkDone.isChecked = currTodo.isChecked
        // add strikethru
        toggleStrikeThrough(holder.itemView.txtItem,holder.itemView.chkDone.isChecked)

        // lambda / anonymous
        holder.itemView.chkDone.setOnCheckedChangeListener { _,b ->
            toggleStrikeThrough(holder.itemView.txtItem, b)
            currTodo.isChecked = !currTodo.isChecked
        }

    }

    // function that adds a strikethru
    private fun toggleStrikeThrough(txtItem: TextView, isChecked: Boolean){
        if(isChecked){
            txtItem.paintFlags = txtItem.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        }else{
            txtItem.paintFlags = txtItem.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
        }
    }

    override fun getItemCount(): Int {
        return todos.size
    }

    // add item
    fun addTodo(todo: Todo){
        todos.add(todo)
        // to refresh recyclerview
        notifyItemInserted(todos.size-1)
    }

    // delete item
    fun deleteTodo(){
        todos.removeAll{
            todo -> todo.isChecked
        }
        notifyDataSetChanged()
    }

}