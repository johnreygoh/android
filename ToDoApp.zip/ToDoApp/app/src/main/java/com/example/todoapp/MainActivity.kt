package com.example.todoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.btnAdd
import kotlinx.android.synthetic.main.activity_main.btnDelete
import kotlinx.android.synthetic.main.activity_main.rvTodolist
import kotlinx.android.synthetic.main.activity_main.txtTodo

class MainActivity : AppCompatActivity() {

    private lateinit var todoAdapter: TodoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //create a variable for a list to send to recyclerview
        todoAdapter = TodoAdapter(mutableListOf())

        // bind rv to adapter
        rvTodolist.adapter = todoAdapter
        rvTodolist.layoutManager = LinearLayoutManager(this)

        //button click
        btnAdd.setOnClickListener {
            val todoTitle = txtTodo.text.toString()
            if(todoTitle.isNotEmpty()){
                val todo = Todo(todoTitle)
                todoAdapter.addTodo(todo)
                txtTodo.text.clear()
            }
        }

        btnDelete.setOnClickListener {
            todoAdapter.deleteTodo()
        }



    }
}