package com.example.demo2

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_1.btnCall
import kotlinx.android.synthetic.main.activity_1.txt_phonenumber

class Activity1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_1)

        btnCall.setOnClickListener{
            var pn = txt_phonenumber.text.toString()
            var intentcall = Intent(Intent.ACTION_VIEW, Uri.parse("tel:$pn"))
            startActivity(intentcall)
        }


    }
}