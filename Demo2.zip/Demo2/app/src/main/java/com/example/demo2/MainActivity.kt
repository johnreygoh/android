package com.example.demo2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.btnActivity1
import kotlinx.android.synthetic.main.activity_main.btnActivity2
import kotlinx.android.synthetic.main.activity_main.btnActivity3

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d("test:","This is onCreate")

        // set button actions to call activities
        btnActivity1.setOnClickListener{
            val act1 = Intent(this,Activity1::class.java)
            startActivity(act1)
        }

        btnActivity2.setOnClickListener{
            val act2 = Intent(this, Activity2::class.java)
            startActivity(act2)
        }

        btnActivity3.setOnClickListener{
            val act3 = Intent(this, Activity3::class.java)
            startActivity(act3)
        }




    }

    override fun onStart() {
        super.onStart()
        Log.d("test:","This is onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("test:","This is onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("test:","This is onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("test:","This is onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("test:","This is onDestroy")
    }

}