package com.example.demo2

import android.app.SearchManager
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_2.btnSearch
import kotlinx.android.synthetic.main.activity_2.txt_searchterm

class Activity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)

        btnSearch.setOnClickListener{

            var searchterm:String = txt_searchterm.text.toString()
            val searchweb = Intent(Intent.ACTION_WEB_SEARCH)
            searchweb.putExtra(SearchManager.QUERY,searchterm)
            startActivity(searchweb)

        }


    }
}