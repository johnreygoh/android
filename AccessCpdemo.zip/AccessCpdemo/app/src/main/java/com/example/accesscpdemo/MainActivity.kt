package com.example.accesscpdemo

import android.annotation.SuppressLint
import android.content.ContentValues
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast



class MainActivity : AppCompatActivity() {

    var CONTENT_URI = Uri.parse("content://com.demo.user.provider/users")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    @SuppressLint("Range")
    fun onClickLoadData(view: View?){

        // inserting table details in the textview
        val resultView = findViewById<View>(R.id.res) as TextView

        // another way of specifying URI
        val cursor = contentResolver.query(
            Uri.parse("content://com.demo.user.provider/users"),
            null, null,null,null)

        // iteration to display to textview
        if(cursor!!.moveToFirst()){
            // use string builder
            val strbuild = StringBuilder()
            while(!cursor.isAfterLast){
                strbuild.append("""
                    
                    ${cursor.getString(cursor.getColumnIndex("id"))} - ${cursor.getString(cursor.getColumnIndex("name"))}
                """.trimIndent())
                cursor.moveToNext()
            }

            resultView.text = strbuild
        } else {
            resultView.text = "No Records Found"
        }
    }

}