package com.example.demo1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.demo1.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

//    lateinit var text1:TextView
//    lateinit var input1:EditText
//    lateinit var input2:EditText
//    lateinit var button1:Button

    lateinit var binding:ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        // setContentView(R.layout.activity_main)
        setContentView(binding.root)

        binding.btnSubmit1.setOnClickListener{
            binding.textView1.text = "This uses view binding"
            var fn = binding.txtFirstname.text.toString()
            var ln = binding.txtLastname.text.toString()
            var message:String = "Good day $fn $ln!"
            val mytoast = Toast.makeText(applicationContext,message,Toast.LENGTH_LONG)
            mytoast.show()
        }


//        text1 = findViewById(R.id.textView1)
//        input1 = findViewById(R.id.txt_firstname)
//        input2 = findViewById(R.id.txt_lastname)
//        button1 = findViewById(R.id.btn_submit1)
//
//        text1.text = "My Activity 1"
//
//        button1.setOnClickListener{
//            var fn = input1.text.toString()
//            var ln = input2.text.toString()
//            val message:String = "Hi $fn $ln!"
//            val toastMessage = Toast.makeText(applicationContext,message,Toast.LENGTH_LONG)
//            toastMessage.show()
//        }

        // synthetics
//        btn_submit1.setOnClickListener{
//            textView1.text = "My Activity 1"
//            var fn = txt_firstname.text.toString()
//            var ln = txt_lastname.text.toString()
//            var message:String = "Hello $fn $ln!"
//            val toastMessage = Toast.makeText(applicationContext,message,Toast.LENGTH_LONG)
//            toastMessage.show()
//        }







    }

}